<?php
/**
 * PHPMyLicense Development Enviroment v11.51.617
 * User: jholl
 * Date: 03/04/17
 * Time: 18:11
 */


require_once 'system/autoloader.php';
$Logged = $Tools->CheckIfLogged($_SESSION);
if(!$Logged)
{
    header("Location: login.php?go=".base64_encode($_SERVER["REQUEST_URI"])."");
}

$sql = "SELECT * FROM settings";
$query = $DatabaseHandler->query($sql);
if($query)
{
    $data = $query->fetch_array();
    $configurations = json_decode($data['configurations'], true);
    //$purchasecode = $data['purchasecode'];
    $clientId = $configurations['payments']['clientid'];
    $clientSecret = $configurations['payments']['clientsecret'];
    $ApiMode = $configurations['payments']['apimode'];
}

if(file_exists('renew/igniter.php'))
{
    @require('renew/igniter.php');
    if(MODULE_PAYMENTS_ON === true)
    {
        $enabled = true;
    }else{
        $enabled = false;
    }
}else{
    $enabled = false;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Giovanne Oliveira">
    <link rel="shortcut icon" href="<?php echo ASSETS_URL;?>/img/favicon.png">

    <title><?php echo PRODUCT_NAME;?> Payment Settings</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo ASSETS_URL;?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ASSETS_URL;?>/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo ASSETS_URL;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo ASSETS_URL;?>/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="<?php echo ASSETS_URL;?>/css/owl.carousel.css" type="text/css">

    <!--right slidebar-->
    <link href="<?php echo ASSETS_URL;?>/css/slidebars.css" rel="stylesheet">

    <!-- Custom styles for this template -->

    <link href="<?php echo ASSETS_URL;?>/css/style.css" rel="stylesheet">
    <link href="<?php echo ASSETS_URL;?>/css/style-responsive.css" rel="stylesheet" />



    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="<?php echo ASSETS_URL;?>/js/html5shiv.js"></script>
    <script src="<?php echo ASSETS_URL;?>/js/respond.min.js"></script>
    <![endif]-->
</head>

<body>

<section id="container" >
    <!--header start-->
    <header class="header white-bg">
        <div class="sidebar-toggle-box">
            <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
        </div>
        <!--logo start-->
        <a href="index.html" class="logo">PHP<span>MyLicense</span></a>
        <!--logo end-->
        <div class="nav notify-row" id="top_menu">

        </div>
        <div class="top-nav ">

            <?php include 'assets/inc/topbar.php';?>
        </div>
    </header>
    <!--header end-->
    <!--sidebar start-->
    <?php include 'assets/inc/sidebar.php';?>
    <!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!--state overview start-->
            <?php include 'assets/inc/overview.php';?>
            <!--state overview end-->
            <div class="row">
                <div class="col-md-12">
                    <!--work progress start-->
                    <section class="panel">
                        <header class="panel-heading">
                            Payments Settings
                        </header>
                        <div class="panel-body">
                            <?php

                            if($enabled == true)
                            { ?>
                            <form class="form-horizontal tasi-form" id="frmSettings">
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Automatic Renewal Enabled</label>
                                    <div class="col-sm-10">
                                        <div id="payments_enabled" class="switch switch-square">
                                            <input class="switch" id="payments_enabled" <?php
                                            $checked = $configurations['payments']['active'];
                                            if($checked == true)
                                            {
                                                echo 'checked';
                                            }

                                            ?> type="checkbox" />
                                        </div>
                                        <span class="help-block">Enable or Disable the Support for Automatic License Renewal</span>
                                    </div>
                                </div>
                                <div class="form-group" id="payments_settings_container" <?php
                                $checked = $configurations['payments']['active'];
                                if($checked == false)
                                {
                                    echo 'style="display:none"';
                                }
                                ?>>

                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Client ID</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" id="clientid" value="<?php echo $configurations['payments']['clientid'];?>" type="text" placeholder="Payment Gateway Client ID">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Client Secret</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" id="clientsecret" value="<?php echo $configurations['payments']['clientsecret'];?>" type="text" placeholder="Payment Gateway Client Secret">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Payment API Mode</label>
                                        <div class="col-sm-10">
                                            <select id="apimode" class="form-control m-bot15">
                                                <option <?php if($configurations['payments']['apimode'] == 'sandbox'){echo 'selected';}?> value="sandbox">Sandbox</option>
                                                <option <?php if($configurations['payments']['apimode'] == 'live'){echo 'selected';}?> value="live">Live</option>
                                            </select>
                                            <span class="help-block">PayPal API Mode - Check Documentation for futher informations.</span>
                                        </div>
                                    </div>




                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label"></label>
                                    <button type="button" id="btnUpdate" class="btn btn-info btn-lg"><i class="fa fa-refresh" id="spinner"></i> <span id="btnText">Update Settings</span></button>
                                </div>
                            </form>
                            <?php }else{ ?>

                                <div class="alert alert-block alert-danger fade in" id="msgError">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="fa fa-times"></i>
                                    </button>
                                    <strong>Oh snap!</strong> <div id="msgError_Text">This module is not present.</div>
                                </div>

                            <?php } ?>

                        </div>
                    </section>
                    <!--work progress end-->
                </div>

        </section>
    </section>
    <!--main content end-->

    <!--footer start-->
    <?php include 'assets/inc/footer.php';?>
    <!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo ASSETS_URL;?>/js/jquery.js"></script>
<script src="<?php echo ASSETS_URL;?>/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo ASSETS_URL;?>/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo ASSETS_URL;?>/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo ASSETS_URL;?>/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="<?php echo ASSETS_URL;?>/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="<?php echo ASSETS_URL;?>/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="<?php echo ASSETS_URL;?>/js/owl.carousel.js" ></script>
<script src="<?php echo ASSETS_URL;?>/js/jquery.customSelect.min.js" ></script>
<script src="<?php echo ASSETS_URL;?>/js/respond.min.js" ></script>

<!--right slidebar-->
<script src="<?php echo ASSETS_URL;?>/js/slidebars.min.js"></script>

<!--common script for all pages-->
<script src="<?php echo ASSETS_URL;?>/js/common-scripts.js"></script>

<!--custom switch-->
<script src="<?php echo ASSETS_URL;?>/js/bootstrap-switch.js"></script>

<?php
include 'assets/inc/changepwd.php';
?>

<script>
    //$("[data-toggle='switch']").wrap('<div class="switch" />').parent().bootstrapSwitch();


    $("#payments_enabled").on("switch-change", function(event, data)
    {
        if(data.value == true)
        {
            $("#payments_settings_container").slideDown();
        }else{
            $("#payments_settings_container").slideUp();
        }
    });

    $("#btnUpdate").click(function(e){

        var payments_enabled = $("#payments_enabled").bootstrapSwitch('status');
        var clientid = $("#clientid").val();
        var clientsecret = $("#clientsecret").val();
        var apimode = $("#apimode").val();
        var btn = $("#btnText");
        var spinner = $("#spinner");
        $.ajax({

            type: "POST",
            data: {
                payments_enabled:payments_enabled,
                clientid:clientid,
                clientsecret:clientsecret,
                apimode:apimode,
                token:'<?php echo $TOTP->generateCode();?>',
                handler: 'updatepaymentsettings'
            },

            url: "ajax/",
            dataType: "json",
            success: function (result) {

                if(result.status == 200)
                {
                    spinner.removeClass('fa-spin');
                    toastr[result.message.type](result.message.text, result.message.header);
                    btn.html('Updated.');
                }else{
                    btn.removeClass('disabled');
                    spinner.removeClass('fa-spin');
                    toastr[result.message.type](result.message.text, result.message.header);
                    btn.html('Update Settings');
                }




            },
            beforeSend: function () {

                btn.html('Updating...');
                btn.addClass('disabled');
                spinner.addClass('fa-spin');

            },
            error: function () {
                btn.removeClass('disabled');
                spinner.removeClass('fa-spin');
                btn.html('Error!');
                btn.addClass('btn-danger');
                toastr['error']("Unknown Error. Contact the support team.", "Oops!");
            }
        });


    });

</script>

</body>
</html>

