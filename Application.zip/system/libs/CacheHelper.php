<?php

/**
 * Giovanne Oliveira - JhollsOliver.me.
 * Date: 14/02/2017
 * Time: 09:26
 */
class CacheHelper
{
        public function GetFileFromCache($filename)
        {
            
        }
}