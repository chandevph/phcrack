<?php
class Validation extends Validation_Core
{
	function validate_license($value, $params = array())
	{
		return true;
	}
	function validate_system_path($value, $params = array())
	{
		return true;
	}
}
