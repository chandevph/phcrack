<?php
/**
 * Callbacks class
 */
include_once('includes/vendor/autoload.php');

class Callbacks extends Callbacks_Core
{
    function is_installed($params = array())
    {
        $installedVersion = json_decode(file_get_contents('../system/buildinfo.json'));
        $current_version = '3.7.1';
        if ( is_file(BASE_PATH . '../system/config.php') ) {
            include_once '../system/config.php';
            if(isset($BaseURL)) {
                $this->error = 'System already appears to be installed.';
                return true;
            }
        }
        elseif ( $installedVersion->version <= $current_version ) {
            $this->error = 'You are already running the latest version of the app.';
            return true;
        }
        return true;
    }
    
    function install($params = array())
    {

        $dbconf = array(
            'db_host' => $_SESSION['params']['db_hostname'],
            'db_user' => $_SESSION['params']['db_username'],
            'db_pass' => $_SESSION['params']['db_password'],
            'db_name' => $_SESSION['params']['db_name'],
            'db_encoding' => 'utf8',
        );
        if ( !$this->db_init($dbconf) ) {
            return false;
        }
        $replace = array(
            '{:db_prefix}' => 'my_',
            '{:db_engine}' => in_array('innodb', $this->db_engines) ? 'InnoDB' : 'MyISAM',
            '{:db_charset}' => $this->db_version >= '4.1' ? 'DEFAULT CHARSET=utf8' : '',
            '{:website}' => $_SESSION['params']['virtual_path']
        );
        $tpl = file_get_contents('includes/configfile.tpl');
        $search = array('<%dbhost%>', '<%dbuser%>', '<%dbpass%>', '<%dbdatabase%>', '<%baseurl%>', '<%purchasecode%>');
        $replace = array(addslashes($_SESSION['params']['db_hostname']), addslashes($_SESSION['params']['db_username']), addslashes($_SESSION['params']['db_password']), addslashes($_SESSION['params']['db_name']), addslashes($_SESSION['params']['virtual_path']), addslashes($_SESSION['params']['license_number']));
        $config_file = str_replace($search, $replace, $tpl);
        file_put_contents(rtrim($_SESSION['params']['system_path'], '/').'/system/config.php', $config_file);

        $sql = file_get_contents('sql/database.sql');
        $decsql = decrypt($sql);

        if($this->db_import_sql($decsql))
        {
            return true;
            $this->db_close();
        }else{
            return false;
            $this->db_close();
        }
        //unlink('sql/db.sql');
        //unlink('sql/'.$filename.'.sql');
    }
    function setup_admin($params = array())
    {
        $dbconf = array(
            'db_host' => $_SESSION['params']['db_hostname'],
            'db_user' => $_SESSION['params']['db_username'],
            'db_pass' => $_SESSION['params']['db_password'],
            'db_name' => $_SESSION['params']['db_name'],
            'db_encoding' => 'utf8',
        );
        if ( !($db = $this->db_init($dbconf)) ) {
            return false;
        }
        $purchasecode = $_SESSION['params']['license_number'];
        //$this->db_query("INSERT INTO `users` (`usrid`, `username`, `password`, `email`, `last_login`, `last_login_ip`, `role`, `license_expiration_date`, `status`) VALUES (1, '".$this->db_escape($_SESSION['params']['username'])."', '".md5($this->db_escape($_SESSION['params']['user_password']))."', '".$this->db_escape($_SESSION['params']['user_email'])."', '2014-03-16', '127.0.0.1', 5, '2014-03-23', 1)");
        $i = 0;
        //if($this->db_query("INSERT INTO `users` (`username`, `password`, `name`, `email`, `avatar`, `last_login_ip`, `last_login_timestamp`, `role`, `status`) VALUES ('".$this->db_escape($_SESSION['params']['username'])."', '".hash('sha256', $this->db_escape($_SESSION['params']['user_password']))."', '".$this->db_escape($_SESSION['params']['name'])."', '".$this->db_escape($_SESSION['params']['user_email'])."', ' ', '127.0.0.1', '1433170800', 'root', 'active');"))
        if($this->db_query("INSERT INTO `users` (`username`, `password`, `name`, `email`, `avatar`, `last_login_ip`, `last_login_timestamp`, `permissions`, `status`, `2fa`, `2fa_secret`) VALUES ('".$this->db_escape($_SESSION['params']['username'])."', '".hash('sha256', $this->db_escape($_SESSION['params']['user_password']))."', '".$this->db_escape($_SESSION['params']['name'])."', '".$this->db_escape($_SESSION['params']['user_email'])."', '', '127.0.0.1', '', 'root', 'active', 0, NULL)"))
        {
            $i++;
        }
        $configurations = '{"serialmask":"PML-####-####-####-####","returndata":"false","encryptionkey":"01AuDadtavC7J34HFkk4mThdAF2KZihe","return_encrypted":"false","updatechannel":"stable","signresponse":"true","signaturetype":"sha1","mail":{"active":"false","smtp_user":"noreply@phpmylicense.us","smtp_pass":"","smtp_host":"mail.phpmylicense.us","smtp_port":"25","smtp_security":"none","smtp_sender":"noreply@phpmylicense.us"},"encryption_key":"G2b20BdBSVmRE7VavLEzsBHQfYvrIIef","payments":{"active":"true","clientid":"","clientsecret":"apimode","sandbox":""}}';
        if($this->db_query("INSERT INTO `settings` (`purchasecode`, `configurations`) VALUES ('$purchasecode', '$configurations');"))
        {
            $i++;
        }
        $this->db_close();
        if($i == 2)
        {
            return true;
        }else{
            return false;
        }
    }
}
