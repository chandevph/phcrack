<?php

$language = array(
    'key_1' => 'Text 1',
    'key_2' => 'Text 2',
);
