<?php
/**
 * Created by PhpStorm.
 * User: jholl
 * Date: 06/06/17
 * Time: 17:37
 */

include_once 'system/autoloader.php';
$Logged = $Tools->CheckIfLogged($_SESSION);
if(!$Logged)
{
    header("Location: login.php?go=".base64_encode($_SERVER["REQUEST_URI"])."");
}

$sql = "SELECT * FROM settings";
$query = $DatabaseHandler->query($sql);
if($query)
{
    $data = $query->fetch_array();
    $configurations = json_decode($data['configurations'], true);
    $purchasecode = $data['purchasecode'];
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon.png">

    <title><?php echo PRODUCT_NAME;?> - User PRofile</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo ASSETS_URL;?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ASSETS_URL;?>/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo ASSETS_URL;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
      <!--right slidebar-->
      <link href="<?php echo ASSETS_URL;?>/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo ASSETS_URL;?>/css/style.css" rel="stylesheet">
    <link href="<?php echo ASSETS_URL;?>/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo ASSETS_URL;?>/js/html5shiv.js"></script>
      <script src="<?php echo ASSETS_URL;?>/js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <header class="header white-bg">
        <div class="sidebar-toggle-box">
            <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
        </div>
        <!--logo start-->
        <a href="index.html" class="logo">PHP<span>MyLicense</span></a>
        <!--logo end-->
        <div class="nav notify-row" id="top_menu">

        </div>
        <div class="top-nav ">

            <?php include 'assets/inc/topbar.php';?>
        </div>
    </header>
      <!--header end-->
     <!--sidebar start-->
        <?php include 'assets/inc/sidebar.php';?>
    <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                  <aside class="profile-nav col-lg-3">
                      <section class="panel">
                          <div class="user-heading round">
                              <a href="#">
                                  <img src="<?php echo $Tools->GetAvatarURL($_SESSION['name']);?>" alt="">
                              </a>
                              <h1><?php echo $_SESSION['name'];?></h1>
                              <p><?php echo $_SESSION['email'];?></p>
                          </div>

                          <ul class="nav nav-pills nav-stacked">
                              <li class="active"><a href="#"> <i class="fa fa-user"></i> Profile</a></li>
                              <li><a href="#" onClick="swal('Hmm...', 'This feature will be released soon!', 'warning');"> <i class="fa fa-calendar"></i> Activity Log</a></li>
                              <li><a href="#" onClick="swal('Hmm...', 'This feature will be released soon!', 'warning');"> <i class="fa fa-edit"></i> Edit profile</a></li>
                          </ul>

                      </section>
                  </aside>
                  <aside class="profile-info col-lg-9">
                      <section class="panel">
                          <div class="bio-graph-heading">
                              Soon, PHPMyLicense will display security tips for your Applications, right here!
                          </div>
                          <div class="panel-body bio-graph-info">
                              <h1>Bio Graph</h1>
                              <div class="row">
                                  <div class="bio-row">
                                      <p><span>Name </span>: <?php echo $_SESSION['name'];?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>Email </span>: <?php echo $_SESSION['email'];?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>Purchase Code </span>: <?php echo $purchasecode;?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>License Status </span>: <span class="label label-success">Active</span></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span>2 Factor Auth</span>: <?php if($_SESSION['tfa'] == true) {echo('<span class="label label-success">Active</span>');}else{echo('<span class="label label-danger">Not Active</span>');}?></p>
                                  </div>
                        
                              </div>
                          </div>
                      </section>
                      <section class="panel">
                          <header class="panel-heading">
                             Personal Settings
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" id="frmPersonalSettings">
                                  <!--<div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label"></label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control">
                                      </div>
                                  </div>-->
                                  <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">System Version</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo PRODUCT_VERSION;?>" type="text" placeholder="Version" disabled="demo">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Assets URL</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo ASSETS_URL;?>" type="text" placeholder="Version" disabled="demo">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">API Endpoint</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo PHPMYLICENSE_API;?>" type="text" placeholder="Version" disabled="demo">
                                    </div>
                                </div>
                              </form>
                          </div>
                      </section>
                  </aside>
              </div>

              <!-- page end-->
          </section>
      </section>
      <!--main content end-->

      

      <!--footer start-->
    <?php include 'assets/inc/footer.php';?>
    <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo ASSETS_URL;?>/js/jquery.js"></script>
    <script src="<?php echo ASSETS_URL;?>/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo ASSETS_URL;?>/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo ASSETS_URL;?>/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo ASSETS_URL;?>/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS_URL;?>/jquery-knob/js/jquery.knob.js"></script>
    <script src="<?php echo ASSETS_URL;?>/js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="<?php echo ASSETS_URL;?>/js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="<?php echo ASSETS_URL;?>/js/common-scripts.js"></script>
    
    <!-- SWAL -->
<script src="//cdn.jsdelivr.net/sweetalert2/6.5.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="//cdn.jsdelivr.net/sweetalert2/6.5.6/sweetalert2.min.css">



  </body>
</html>