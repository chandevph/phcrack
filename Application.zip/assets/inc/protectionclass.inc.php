<?php /**
* PHPMyLicense v3.x - Copyright 2020
*
* PHP version > 5.4
*
* @package    PHPMyLicense
* @author     Giovanne Oliveira <support@phpmylicense.us>
* @copyright  2009 - 2020 PHPMyLicense
* @license    http://www.php.net/license/3_01.txt  PHP License 3.01
* @version    v7.6.0
* @link       https://phpmylicense.us */

