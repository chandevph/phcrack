<?php
/**
 * PHPMyLicense Development Platform.
 * User: giova
 * Date: 14/11/2018
 * Time: 21:02
 * Project: phpmylicense
 */
if(defined('OFFLINE_MODE'))
{
    $messages = '{"total":1,"messages":[{"id":"13","header":"T2ZmbGluZSBNb2Rl","text":"WW91J3JlIGluIE9mZmxpbmUgTW9kZS4=","icon_class":"fa fa-diamond bg-primary","added":"00","redirurl":"#","status":"active"}]}';
}else{
    $messages = @file_get_contents(PHPMYLICENSE_API.'/public/getmessages?purchasecode='.$purchasecode);
}
$messages = json_decode($messages, true);
?>

<header class="header white-bg">
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="index.html" class="logo">PHP<span>MyLicense</span></a>
    <!--logo end-->
    <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
            <!-- inbox dropdown start-->
            <li id="header_inbox_bar" class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <i class="fa fa-envelope-o"></i>
                    <?php
                    if($messages['total'] > 0){
                        echo '<span class="badge bg-important">'.$messages['total'].'</span>';
                    }?>
                    
                </a>
                <ul class="dropdown-menu extended inbox">
                    <div class="notify-arrow notify-arrow-red"></div>
                    <li>
                        <?php if($messages['total'] == 0)
                            {
                                echo '<p class="red">You don\'t have any message</p>';
                            }else{
                                echo '<p class="red">You have '.$messages['total'].' new messages</p>';
                            } ?>


                    <?php if($messages['total'] > 0)
                        {
                            foreach($messages['messages'] as $res)
                                {
                                    ?>
                    <li>
                        <a href="<?php if(strlen($res['redirurl']) > 0) { echo $res['redirurl']; }else{ echo '#'; }?>">
                            <span class="subject">
                                    <span class="from"><?php echo base64_decode($res['header']);?></span>
                                    <span class="time"><?php echo $res['added'];?></span>
                                    </span>
                            <span class="message">
                                        <?php echo base64_decode($res['text']);?>
                                    </span>
                        </a>
                    </li>
                    <?php
                                }
                        } ?>
                </ul>
            </li>
            <!-- inbox dropdown end -->
        </ul>
        <!--  notification end -->

    </div>
    <div class="top-nav ">

        <?php include 'assets/inc/topbar.php';?>
    </div>
</header>
