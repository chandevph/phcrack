<?php
/**
 * Unreal Studio
 * Project: UnrealLicensing
 * User: jhollsoliver
 * Date: 04/06/15
 * Time: 15:50
 */
?>
<footer class="site-footer navbar-fixed-bottom">
    <div class="text-center">
        2020 &copy; <?php echo PRODUCT_NAME.' '.PRODUCT_VERSION;?> by Giovanne Oliveira.
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>